class Directions
{
  String? humanReadableAddress , locationName , locationId ;
  double? locationLatitude , locationLongitude;

  Directions({
   this.humanReadableAddress,
   this.locationId,
   this.locationLatitude,
   this.locationLongitude,
   this.locationName,
  });

}